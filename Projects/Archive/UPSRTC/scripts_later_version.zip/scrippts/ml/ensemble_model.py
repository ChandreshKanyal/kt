"""
Ensemble Anomaly Detection Model
=================================
Contains model classes and training/packaging functionality
"""

import pandas as pd
import numpy as np
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
import joblib
import boto3
from io import StringIO
import warnings
warnings.filterwarnings('ignore')


# ============================================================================
# MODEL CLASSES (FIXED)
# ============================================================================

class TimeSeriesAnomalyModel:
    """Time series anomaly detection using IQR method"""
    
    def __init__(self, contamination=0.05):
        self.contamination = contamination
        self.threshold_low = None
        self.threshold_high = None
        
    def fit(self, data):
        Q1 = np.percentile(data, 25)
        Q3 = np.percentile(data, 75)
        IQR = Q3 - Q1
        self.threshold_low = Q1 - 1.5 * IQR
        self.threshold_high = Q3 + 1.5 * IQR
        return self
    
    def predict(self, data):
        return ((data < self.threshold_low) | (data > self.threshold_high)).astype(int)


class AnomalyDetectionEnsemble:
    """Ensemble of 3 models - FIXED VERSION"""
    
    def __init__(self, contamination=0.05):
        self.contamination = contamination
        self.income_model = None
        self.passenger_model = None
        self.isolation_forest = None
        self.scaler = StandardScaler()
        self.is_fitted = False
        self.trained_route_ids = None
        
    def fit(self, df):
        """Fit all three models"""
        print("Fitting Anomaly Detection Ensemble...")
        
        # ✅ FIX: Work on a copy to avoid modifying input
        df_work = df.copy()

        # Store route IDs this model was trained on
        if 'route_id' in df_work.columns:
            self.trained_route_ids = sorted(df_work['route_id'].unique().tolist())
            print(f"✓ Training on {len(self.trained_route_ids)} routes: {self.trained_route_ids}")

        # Extract temporal features
        df_work['start_time'] = df_work['start_time'].astype(str).str.split('.').str[0]
        df_work['start_time_parsed'] = pd.to_datetime(df_work['start_time'], format="%Y-%m-%d %H:%M:%S", errors="coerce")
        df_work['month'] = df_work['start_time_parsed'].dt.month
        df_work['year'] = df_work['start_time_parsed'].dt.year
        df_work['day'] = df_work['start_time_parsed'].dt.day
        df_work['day_of_week'] = df_work['start_time_parsed'].dt.dayofweek
        
        # 1. Income model
        self.income_model = TimeSeriesAnomalyModel(contamination=self.contamination)
        self.income_model.fit(df_work['total_income'].values)
        print(f"✓ Income model trained: thresholds [{self.income_model.threshold_low:.2f}, {self.income_model.threshold_high:.2f}]")
        
        # 2. Passenger model
        self.passenger_model = TimeSeriesAnomalyModel(contamination=self.contamination)
        self.passenger_model.fit(df_work['total_passengers'].values)
        print(f"✓ Passenger model trained: thresholds [{self.passenger_model.threshold_low:.2f}, {self.passenger_model.threshold_high:.2f}]")
        
        # 3. Isolation Forest
        features = ['month', 'year', 'day', 'day_of_week', 'total_income', 'total_passengers']
        X = df_work[features].fillna(df_work[features].median())
        X_scaled = self.scaler.fit_transform(X)
        
        self.isolation_forest = IsolationForest(
            contamination=self.contamination, 
            random_state=42, 
            n_estimators=100
        )
        self.isolation_forest.fit(X_scaled)
        print(f"✓ Isolation Forest trained: {self.isolation_forest.n_estimators} estimators")
        
        self.is_fitted = True
        return self
    
    def predict(self, df):
        """Predict anomalies - PRESERVES ORIGINAL start_time"""
        # ✅ FIX: Work on separate copy for processing
        df_work = df.copy()
        
        # Parse start_time on working copy
        df_work['start_time'] = df_work['start_time'].astype(str).str.split('.').str[0]
        df_work['start_time_parsed'] = pd.to_datetime(df_work['start_time'], format="%Y-%m-%d %H:%M:%S", errors="coerce")
        df_work['month'] = df_work['start_time_parsed'].dt.month
        df_work['year'] = df_work['start_time_parsed'].dt.year
        df_work['day'] = df_work['start_time_parsed'].dt.day
        df_work['day_of_week'] = df_work['start_time_parsed'].dt.dayofweek
        
        # Get predictions
        income_anomalies = self.income_model.predict(df_work['total_income'].values)
        passenger_anomalies = self.passenger_model.predict(df_work['total_passengers'].values)
        
        features = ['month', 'year', 'day', 'day_of_week', 'total_income', 'total_passengers']
        X = df_work[features].fillna(df_work[features].median())
        X_scaled = self.scaler.transform(X)
        iso_predictions = self.isolation_forest.predict(X_scaled)
        iso_anomalies = (iso_predictions == -1).astype(int)
        
        # Ensemble voting
        ensemble_scores = income_anomalies + passenger_anomalies + iso_anomalies
        ensemble_anomalies = (ensemble_scores >= 2).astype(int)
        
        # ✅ FIX: Add results to ORIGINAL df (preserving original start_time)
        df['income_anomaly'] = income_anomalies
        df['passenger_anomaly'] = passenger_anomalies
        df['iso_anomaly'] = iso_anomalies
        df['ensemble_score'] = ensemble_scores
        df['ensemble_anomaly'] = ensemble_anomalies
        
        # Add temporal features (optional but useful)
        df['month'] = df_work['month']
        df['year'] = df_work['year']
        df['day'] = df_work['day']
        df['day_of_week'] = df_work['day_of_week']
        
        return df


# ============================================================================
# TRAINING & PACKAGING FUNCTION
# ============================================================================

def package_models_to_joblib():
    """
    Train and package models into ensemble_model.joblib
    """
    print("\n" + "="*70)
    print("TRAINING & PACKAGING MODELS INTO JOBLIB")
    print("="*70)
    
    # Configuration
    S3_BUCKET = "test-airflow-chan"
    S3_KEY = "data/top_10.csv000"
    OUTPUT_FILE = "ensemble_model.joblib"
    
    # Load data
    print(f"\nLoading training data from S3...")
    print(f"Bucket: {S3_BUCKET}")
    print(f"Key: {S3_KEY}")
    
    s3 = boto3.client("s3")
    obj = s3.get_object(Bucket=S3_BUCKET, Key=S3_KEY)
    df = pd.read_csv(StringIO(obj['Body'].read().decode('utf-8')))
    print(f"✓ Loaded {len(df):,} transactions\n")
    
    # Train ensemble (all 3 models)
    ensemble = AnomalyDetectionEnsemble(contamination=0.05)
    ensemble.fit(df)
    
    # Save to joblib
    print(f"\n{'='*70}")
    print("SAVING TO JOBLIB")
    print("="*70)
    print(f"\nOutput file: {OUTPUT_FILE}")
    joblib.dump(ensemble, OUTPUT_FILE)
    print(f"✓ Saved successfully")
    
    # Verify
    print("\nVerifying...")
    loaded = joblib.load(OUTPUT_FILE)
    print(f"✓ File can be loaded")
    print(f"✓ Is fitted: {loaded.is_fitted}")
    print(f"✓ Contains 3 models:")
    print(f"  - Income model: {loaded.income_model is not None}")
    print(f"  - Passenger model: {loaded.passenger_model is not None}")
    print(f"  - Isolation Forest: {loaded.isolation_forest is not None}")
    
    print("\n" + "="*70)
    print("✓ PACKAGING COMPLETE")
    print("="*70)
    print(f"✓ Output: {OUTPUT_FILE}")
    print("✓ Ready for production use")
    print("="*70 + "\n")


# ============================================================================
# MAIN
# ============================================================================

if __name__ == "__main__":
    # When run directly, train and package the models
    package_models_to_joblib()