"""
Production Inference Script
===========================
Loads trained model and runs predictions on new data
"""

import pandas as pd
import numpy as np
import joblib
import boto3
from io import StringIO
from datetime import date, datetime
import os
import warnings
warnings.filterwarnings('ignore')

# Import model classes from ensemble_model.py
from ensemble_model import AnomalyDetectionEnsemble, TimeSeriesAnomalyModel


def run_inference():
    """
    Run inference using pre-trained model
    """
    print("\n" + "=" * 70)
    print("RUNNING PRODUCTION INFERENCE (NO TRAINING)")
    print("=" * 70)

    # Configuration
    MODEL_PATH  = "/home/chandresh/scripts/ml/ensemble_model.joblib"
    S3_BUCKET   = "test-airflow-chan"
    run_date    = os.environ.get('RUN_DATE', date.today().strftime('%Y-%m-%d'))
    run_ts      = os.environ.get('RUN_TS',   datetime.now().strftime('%H%M%S'))
    S3_PREFIX   = f"runs/{run_date}/{run_ts}/incremental_data/incre_1_"
    OUTPUT_PATH = "/home/chandresh/scripts/ml/inference_output.csv"
    print(f"Reading from: s3://{S3_BUCKET}/{S3_PREFIX}*")

    # Load pre-trained model
    print("\nLoading trained model...")
    model = joblib.load(MODEL_PATH)
    print("✓ Model loaded")
    print(f"✓ Is fitted: {model.is_fitted}")

    # Load inference data from incremental UNLOAD files
    print(f"\nLoading inference data from S3...")
    s3 = boto3.client("s3")
    paginator = s3.get_paginator("list_objects_v2")
    pages = paginator.paginate(Bucket=S3_BUCKET, Prefix=S3_PREFIX)
    keys = [obj["Key"] for page in pages for obj in page.get("Contents", [])]
    if not keys:
        raise FileNotFoundError(f"No incremental data files found at s3://{S3_BUCKET}/{S3_PREFIX}*")
    frames = []
    for key in keys:
        resp = s3.get_object(Bucket=S3_BUCKET, Key=key)
        frames.append(pd.read_csv(StringIO(resp["Body"].read().decode("utf-8"))))
        print(f"  ✓ Read s3://{S3_BUCKET}/{key}")
    df = pd.concat(frames, ignore_index=True)
    print(f"✓ Loaded {len(df):,} rows from {len(keys)} file(s)")

    # Filter to only the routes the model was trained on
    if model.trained_route_ids is not None:
        before = len(df)
        df = df[df['route_id'].isin(model.trained_route_ids)].copy()
        print(f"✓ Filtered to {len(model.trained_route_ids)} trained routes: {before:,} → {len(df):,} rows")
        if df.empty:
            raise ValueError("No rows remain after filtering to trained route IDs. Check that s3://test-airflow-chan/data/top_10.csv000 contains the top-10 routes.")
    else:
        print("⚠ WARNING: model has no trained_route_ids — running on all routes. Retrain the model to fix this.")

    # Verify start_time exists
    if 'start_time' in df.columns:
        print(f"✓ Original start_time sample: {df['start_time'].iloc[0]}")
    else:
        print("⚠ WARNING: start_time column not found in input data!")

    # Run inference
    print("\nRunning anomaly detection...")
    results = model.predict(df)
    
    # ✅ Verify start_time is preserved
    if 'start_time' in results.columns:
        print(f"✓ start_time PRESERVED after inference: {results['start_time'].iloc[0]}")
    else:
        print("❌ ERROR: start_time was lost during inference!")

    # Calculate summary statistics
    total = len(results)
    anomalies = results['ensemble_anomaly'].sum()

    print("\n" + "=" * 70)
    print("INFERENCE RESULTS")
    print("=" * 70)
    print(f"Total records:        {total:,}")
    print(f"Anomalies detected:   {anomalies:,} ({anomalies/total*100:.2f}%)")
    print(f"Income anomalies:     {results['income_anomaly'].sum():,}")
    print(f"Passenger anomalies:  {results['passenger_anomaly'].sum():,}")
    print(f"Isolation anomalies:  {results['iso_anomaly'].sum():,}")
    print("=" * 70)

    # Save results
    results.to_csv(OUTPUT_PATH, index=False)
    print(f"\n✓ Results saved to: {OUTPUT_PATH}")
    
    # Show output columns
    print(f"\nOutput columns ({len(results.columns)}):")
    print(list(results.columns))
    
    print("=" * 70 + "\n")


if __name__ == "__main__":
    run_inference()