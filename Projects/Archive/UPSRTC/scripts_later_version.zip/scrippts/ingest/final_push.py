from utils.redshift import get_redshift_conn
from datetime import date, datetime
import os

def run_procedure():
    run_date = os.environ.get('RUN_DATE', date.today().strftime('%Y-%m-%d'))
    run_ts   = os.environ.get('RUN_TS',   datetime.now().strftime('%H%M%S'))
    s3_path  = f's3://test-airflow-chan/runs/{run_date}/{run_ts}/rule_engine/classified_anomalies_with_insights.csv'

    conn = get_redshift_conn()
    conn.autocommit = True
    cur = conn.cursor()

    print(f"Loading anomalies from: {s3_path}")

    # Stage into a temp table, then upsert — preserves existing anomalies from prior batches
    cur.execute("DROP TABLE IF EXISTS staging_anomalies_ensemble;")
    cur.execute("CREATE TEMP TABLE staging_anomalies_ensemble (LIKE raw_source_data.anomalies_ensemble);")

    copy_sql = f"""
    COPY staging_anomalies_ensemble
    FROM '{s3_path}'
    IAM_ROLE 'arn:aws:iam::590184098502:role/service-role/AmazonRedshift-CommandsAccessRole-20240718T135548'
    FORMAT AS CSV
    IGNOREHEADER 1
    DELIMITER ','
    TIMEFORMAT 'auto'
    DATEFORMAT 'auto'
    ACCEPTINVCHARS
    TRIMBLANKS;
    """

    cur.execute(copy_sql)

    cur.execute("""
        DELETE FROM raw_source_data.anomalies_ensemble
        WHERE trip_id IN (SELECT DISTINCT trip_id FROM staging_anomalies_ensemble);
    """)

    cur.execute("""
        INSERT INTO raw_source_data.anomalies_ensemble
        SELECT * FROM staging_anomalies_ensemble;
    """)

    cur.close()
    conn.close()

if __name__ == "__main__":
    run_procedure()
