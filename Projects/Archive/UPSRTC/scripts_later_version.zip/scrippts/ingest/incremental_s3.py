from utils.redshift import get_redshift_conn
from datetime import date, datetime
import os

def run_procedure():
    run_date = os.environ.get('RUN_DATE', date.today().strftime('%Y-%m-%d'))
    run_ts   = os.environ.get('RUN_TS',   datetime.now().strftime('%H%M%S'))
    s3_prefix = f's3://test-airflow-chan/runs/{run_date}/{run_ts}/incremental_data/incre_1_'

    conn = get_redshift_conn()
    conn.autocommit = True
    cur = conn.cursor()

    unload_sql = f"""
    UNLOAD ('
        SELECT *
        FROM raw_data.mst_transaction_master_1
        WHERE dwh_crddt >=
        (
            SELECT start_time
            FROM raw_data.data_ingestion_tracking_1
            ORDER BY end_time DESC
            LIMIT 1
        )
    ')
    TO '{s3_prefix}'
    IAM_ROLE 'arn:aws:iam::590184098502:role/service-role/AmazonRedshift-CommandsAccessRole-20240718T135548'
    FORMAT AS CSV
    HEADER
    ALLOWOVERWRITE;
    """

    print(f"UNLOAD destination: {s3_prefix}*")
    cur.execute(unload_sql)

    cur.close()
    conn.close()

if __name__ == "__main__":
    run_procedure()
